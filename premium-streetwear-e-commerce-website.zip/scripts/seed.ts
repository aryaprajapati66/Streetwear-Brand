import { db } from "@/db";
import { seed } from "@/lib/seed";

async function main() {
  await seed();
  await process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
