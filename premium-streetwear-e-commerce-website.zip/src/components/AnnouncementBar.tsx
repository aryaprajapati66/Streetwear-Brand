"use client";

import { useState } from "react";
import { X } from "lucide-react";

export default function AnnouncementBar() {
  const [closed, setClosed] = useState(false);
  if (closed) return null;
  return (
    <div className="bg-bone text-noir text-[11px] md:text-xs tracking-[0.2em] uppercase font-medium relative z-50">
      <div className="overflow-hidden">
        <div className="marquee-strip whitespace-nowrap py-2.5 md:py-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <span key={i} className="mx-8 flex items-center gap-2">
              <span>FREE SHIPPING ON ORDERS OVER $150</span>
              <span className="text-noir-400">✦</span>
              <span>NEW DROP · SHADOW COLLECTION LIVE</span>
              <span className="text-noir-400">✦</span>
              <span>30-DAY FREE RETURNS</span>
              <span className="text-noir-400">✦</span>
            </span>
          ))}
        </div>
      </div>
      <button
        onClick={() => setClosed(true)}
        className="absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:opacity-70"
        aria-label="Close"
      >
        <X size={14} />
      </button>
    </div>
  );
}
