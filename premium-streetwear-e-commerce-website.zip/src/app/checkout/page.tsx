"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";
import { formatPrice } from "@/lib/utils";
import { Lock, ArrowLeft } from "lucide-react";
import Link from "next/link";

export default function CheckoutPage() {
  const { cart, subtotal, clearCart, user } = useStore();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const sub = subtotal();
  const shipping = sub > 150 ? 0 : 12;
  const total = sub + shipping;

  const [form, setForm] = useState({
    email: user?.email || "",
    customerName: user?.name || "",
    address: "",
    city: "",
    postalCode: "",
    country: "US",
  });

  if (cart.length === 0) {
    return (
      <div className="pt-32 md:pt-40 min-h-[70vh] text-center">
        <p className="text-xl text-noir-400">Your cart is empty.</p>
        <Link href="/shop" className="inline-block mt-6 text-bone underline">
          Continue shopping
        </Link>
      </div>
    );
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: cart.map((c) => ({
            productId: c.productId,
            name: c.name,
            slug: c.slug,
            image: c.image,
            size: c.size,
            quantity: c.quantity,
            price: c.price,
          })),
        }),
      });
      if (!res.ok) throw new Error("Failed");
      const order = await res.json();
      clearCart();
      router.push(`/profile?order=${order.id}`);
    } catch {
      setError("Something went wrong. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="pt-28 md:pt-32">
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-12">
        <Link href="/cart" className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-noir-400 hover:text-bone mb-6">
          <ArrowLeft size={14} /> BACK TO CART
        </Link>
        <h1 className="text-4xl md:text-6xl font-black tracking-[-0.03em] mb-10">CHECKOUT</h1>

        <div className="grid lg:grid-cols-[1fr_400px] gap-12">
          <form onSubmit={submit} className="space-y-6">
            <div>
              <h2 className="text-sm tracking-[0.25em] text-noir-400 mb-4">CONTACT</h2>
              <input
                type="email"
                required
                placeholder="Email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500"
              />
            </div>

            <div>
              <h2 className="text-sm tracking-[0.25em] text-noir-400 mb-4">SHIPPING ADDRESS</h2>
              <div className="grid md:grid-cols-2 gap-3">
                <input
                  required
                  placeholder="Full name"
                  value={form.customerName}
                  onChange={(e) => setForm({ ...form, customerName: e.target.value })}
                  className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500"
                />
                <input
                  required
                  placeholder="Address"
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500 md:col-span-2"
                />
                <input
                  required
                  placeholder="City"
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500"
                />
                <input
                  required
                  placeholder="Postal code"
                  value={form.postalCode}
                  onChange={(e) => setForm({ ...form, postalCode: e.target.value })}
                  className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500"
                />
                <select
                  value={form.country}
                  onChange={(e) => setForm({ ...form, country: e.target.value })}
                  className="w-full bg-noir border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none md:col-span-2"
                >
                  <option value="US">United States</option>
                  <option value="CA">Canada</option>
                  <option value="UK">United Kingdom</option>
                  <option value="EU">Europe</option>
                  <option value="AU">Australia</option>
                </select>
              </div>
            </div>

            <div>
              <h2 className="text-sm tracking-[0.25em] text-noir-400 mb-4">PAYMENT</h2>
              <div className="border border-white/15 p-6 text-center">
                <Lock size={20} className="mx-auto text-noir-500 mb-3" />
                <p className="text-sm text-noir-400">Secure payment processing</p>
                <p className="text-xs text-noir-500 mt-1">Demo mode — no real charges</p>
              </div>
            </div>

            {error && <p className="text-sm text-red-400">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-bone text-noir py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 transition-colors btn-press disabled:opacity-60"
            >
              {loading ? "PROCESSING..." : `PAY ${formatPrice(total)}`}
            </button>
          </form>

          {/* Summary */}
          <div className="lg:sticky lg:top-28 lg:self-start bg-noir-900 border border-white/10 p-6">
            <h2 className="text-xl font-bold mb-6">ORDER SUMMARY</h2>
            <div className="space-y-3 mb-6">
              {cart.map((item) => (
                <div key={`${item.productId}-${item.size}`} className="flex gap-3 text-sm">
                  <div className="relative w-14 h-18 bg-noir-800 shrink-0">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{item.name}</p>
                    <p className="text-xs text-noir-500">{item.size} × {item.quantity}</p>
                  </div>
                  <div className="text-right shrink-0">{formatPrice(item.price * item.quantity)}</div>
                </div>
              ))}
            </div>
            <div className="space-y-2 text-sm border-t border-white/10 pt-4">
              <div className="flex justify-between">
                <span className="text-noir-400">Subtotal</span>
                <span>{formatPrice(sub)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-noir-400">Shipping</span>
                <span>{shipping === 0 ? "FREE" : formatPrice(shipping)}</span>
              </div>
              <div className="pt-2 border-t border-white/10 flex justify-between text-base font-bold">
                <span>Total</span>
                <span>{formatPrice(total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
