"use client";

import { useState } from "react";
import Image from "next/image";
import { Heart, Minus, Plus, Truck, ShieldCheck, RotateCcw, ChevronDown } from "lucide-react";
import { useStore } from "@/lib/store";
import { formatPrice, cn } from "@/lib/utils";
import Breadcrumbs from "@/components/Breadcrumbs";

type Product = {
  id: number;
  slug: string;
  name: string;
  description: string | null;
  price: number;
  compareAtPrice: number | null;
  category: string;
  collection: string;
  colors: string[];
  sizes: string[];
  inventory: Record<string, number>;
  images: string[];
  rating: number;
  reviewCount: number;
  materials: string | null;
  gender: string;
};

export default function ProductDetail({ product }: { product: Product }) {
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const [selectedSize, setSelectedSize] = useState<string | null>(product.sizes[0] || null);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [info, setInfo] = useState<"description" | "materials" | "shipping" | "size">("description");
  const [added, setAdded] = useState(false);

  const inStock = selectedSize ? (product.inventory[selectedSize] ?? 0) > 0 : false;

  const handleAdd = () => {
    if (!selectedSize || !inStock) return;
    addToCart(
      {
        productId: product.id,
        name: product.name,
        slug: product.slug,
        image: product.images[0],
        size: selectedSize,
        price: product.price,
      },
      quantity
    );
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  const handleBuyNow = () => {
    if (!selectedSize || !inStock) return;
    addToCart(
      {
        productId: product.id,
        name: product.name,
        slug: product.slug,
        image: product.images[0],
        size: selectedSize,
        price: product.price,
      },
      quantity
    );
    window.location.href = "/checkout";
  };

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8">
      <Breadcrumbs product={product} />

      <div className="grid md:grid-cols-2 gap-8 md:gap-16 mt-6 md:mt-8">
        {/* Gallery */}
        <div>
          <div className="relative aspect-[4/5] bg-noir-800 overflow-hidden mb-3">
            <Image
              src={product.images[selectedImage]}
              alt={product.name}
              fill
              className="object-cover"
              priority
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar">
            {product.images.map((img, i) => (
              <button
                key={i}
                onClick={() => setSelectedImage(i)}
                className={cn(
                  "relative shrink-0 w-20 h-24 md:w-24 md:h-28 bg-noir-800 overflow-hidden border-2 transition-colors",
                  i === selectedImage ? "border-bone" : "border-transparent hover:border-white/30"
                )}
              >
                <Image src={img} alt="" fill className="object-cover" sizes="100px" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="md:sticky md:top-28 md:self-start">
          <p className="text-xs tracking-[0.3em] text-noir-500 mb-2">
            {product.collection.toUpperCase()} · {product.category.toUpperCase()}
          </p>
          <h1 className="text-3xl md:text-5xl font-black tracking-[-0.03em] leading-[0.95]">
            {product.name}
          </h1>

          <div className="flex items-center gap-3 mt-4">
            <div className="flex items-center gap-1 text-sm text-noir-300">
              <span>★</span>
              <span>{product.rating.toFixed(1)}</span>
              <span className="text-noir-500">({product.reviewCount} reviews)</span>
            </div>
          </div>

          <div className="flex items-baseline gap-3 mt-5">
            <span className="text-3xl md:text-4xl font-black">{formatPrice(product.price)}</span>
            {product.compareAtPrice && (
              <>
                <span className="text-lg text-noir-500 line-through">
                  {formatPrice(product.compareAtPrice)}
                </span>
                <span className="text-xs tracking-[0.2em] bg-bone text-noir px-2 py-1 font-bold">
                  -{Math.round((1 - product.price / product.compareAtPrice) * 100)}%
                </span>
              </>
            )}
          </div>
          <p className="text-xs text-noir-500 mt-1">Tax included. Shipping calculated at checkout.</p>

          {/* Colors */}
          {product.colors.length > 1 && (
            <div className="mt-8">
              <div className="text-xs tracking-[0.25em] text-noir-400 mb-3">
                COLOR: <span className="text-bone">{product.colors[0]}</span>
              </div>
              <div className="flex gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c}
                    className="border border-white/15 px-3 py-1.5 text-xs tracking-wide hover:border-bone"
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sizes */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs tracking-[0.25em] text-noir-400">
                SIZE: <span className="text-bone">{selectedSize || "—"}</span>
              </span>
              <button
                onClick={() => setInfo("size")}
                className="text-xs tracking-[0.2em] text-noir-400 hover:text-bone underline underline-offset-4"
              >
                SIZE GUIDE
              </button>
            </div>
            <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
              {product.sizes.map((s) => {
                const stock = product.inventory[s] ?? 0;
                const available = stock > 0;
                return (
                  <button
                    key={s}
                    onClick={() => available && setSelectedSize(s)}
                    disabled={!available}
                    className={cn(
                      "border py-3 text-xs tracking-wider font-bold transition-all",
                      selectedSize === s
                        ? "bg-bone text-noir border-bone"
                        : available
                        ? "border-white/15 hover:border-bone"
                        : "border-white/5 text-noir-600 line-through cursor-not-allowed"
                    )}
                  >
                    {s}
                  </button>
                );
              })}
            </div>
            {selectedSize && (
              <p className="text-xs text-noir-400 mt-3">
                {inStock
                  ? `In stock · ${product.inventory[selectedSize]} available`
                  : "Out of stock"}
              </p>
            )}
          </div>

          {/* Quantity */}
          <div className="mt-8">
            <div className="text-xs tracking-[0.25em] text-noir-400 mb-3">QUANTITY</div>
            <div className="inline-flex items-center border border-white/15">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-12 h-12 flex items-center justify-center hover:bg-white/5"
                aria-label="Decrease"
              >
                <Minus size={14} />
              </button>
              <span className="w-12 text-center text-sm font-bold">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-12 h-12 flex items-center justify-center hover:bg-white/5"
                aria-label="Increase"
              >
                <Plus size={14} />
              </button>
            </div>
          </div>

          {/* CTAs */}
          <div className="mt-8 space-y-3">
            <button
              onClick={handleAdd}
              disabled={!selectedSize || !inStock}
              className={cn(
                "w-full py-4 text-xs tracking-[0.25em] font-bold transition-all btn-press",
                added
                  ? "bg-green-500 text-noir"
                  : "bg-bone text-noir hover:bg-bone/90",
                (!selectedSize || !inStock) && "opacity-40 cursor-not-allowed"
              )}
            >
              {added ? "✓ ADDED TO CART" : !selectedSize ? "SELECT A SIZE" : !inStock ? "OUT OF STOCK" : "ADD TO CART"}
            </button>
            <button
              onClick={handleBuyNow}
              disabled={!selectedSize || !inStock}
              className="w-full py-4 text-xs tracking-[0.25em] font-bold border border-bone hover:bg-bone hover:text-noir transition-colors btn-press disabled:opacity-40 disabled:cursor-not-allowed"
            >
              BUY NOW
            </button>
            <button
              onClick={() => toggleWishlist(product.id)}
              className="w-full py-3 text-xs tracking-[0.25em] font-bold inline-flex items-center justify-center gap-2 hover:text-bone text-noir-300 transition-colors"
            >
              <Heart
                size={14}
                fill={isWishlisted(product.id) ? "#f5f5f0" : "none"}
              />
              {isWishlisted(product.id) ? "SAVED TO WISHLIST" : "ADD TO WISHLIST"}
            </button>
          </div>

          {/* Trust badges */}
          <div className="mt-8 grid grid-cols-3 gap-4 text-xs">
            <div className="flex flex-col items-center text-center gap-1.5 text-noir-400">
              <Truck size={16} />
              <span className="text-[10px] tracking-widest">FREE SHIPPING<br />OVER $150</span>
            </div>
            <div className="flex flex-col items-center text-center gap-1.5 text-noir-400">
              <RotateCcw size={16} />
              <span className="text-[10px] tracking-widest">30-DAY<br />RETURNS</span>
            </div>
            <div className="flex flex-col items-center text-center gap-1.5 text-noir-400">
              <ShieldCheck size={16} />
              <span className="text-[10px] tracking-widest">AUTHENTIC<br />GUARANTEE</span>
            </div>
          </div>

          {/* Info tabs */}
          <div className="mt-10 border-t border-white/10">
            {[
              { key: "description", label: "DESCRIPTION", content: product.description },
              { key: "materials", label: "MATERIALS", content: product.materials || "Premium materials selected for longevity and comfort." },
              {
                key: "shipping",
                label: "SHIPPING",
                content:
                  "Free standard shipping on orders over $150. Standard delivery 3-5 business days. Express delivery 1-2 business days. International shipping available to 40+ countries.",
              },
              {
                key: "size",
                label: "SIZE GUIDE",
                content:
                  "This piece is cut for an oversized fit. We recommend sizing down for a closer fit. Check the size chart for detailed measurements.",
              },
            ].map((tab) => (
              <div key={tab.key} className="border-b border-white/10">
                <button
                  onClick={() => setInfo(tab.key as typeof info)}
                  className="w-full flex items-center justify-between py-4 text-xs tracking-[0.25em] font-bold hover:text-bone"
                >
                  {tab.label}
                  <ChevronDown
                    size={14}
                    className={cn(
                      "transition-transform",
                      info === tab.key && "rotate-180"
                    )}
                  />
                </button>
                {info === tab.key && (
                  <div className="pb-5 text-sm text-noir-300 leading-relaxed animate-fade-in">
                    {tab.content}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
