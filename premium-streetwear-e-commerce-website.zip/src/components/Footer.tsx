import Link from "next/link";
const Icon = ({ d }: { d: string }) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);
const Icons = {
  instagram: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" />
    </svg>
  ),
  youtube: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z" />
      <path d="m9.75 15.02 5.75-3.27-5.75-3.27v6.54z" />
    </svg>
  ),
  twitter: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  ),
};

const GROUPS = [
  {
    title: "SHOP",
    links: [
      { label: "New Arrivals", href: "/shop?new=1" },
      { label: "Men", href: "/shop?gender=men" },
      { label: "Women", href: "/shop?gender=women" },
      { label: "Hoodies", href: "/shop?category=Hoodies" },
      { label: "Tees", href: "/shop?category=Tees" },
      { label: "Accessories", href: "/shop?category=Accessories" },
    ],
  },
  {
    title: "HELP",
    links: [
      { label: "Shipping", href: "/shipping" },
      { label: "Returns", href: "/returns" },
      { label: "Size Guide", href: "/size-guide" },
      { label: "Contact", href: "/contact" },
      { label: "FAQ", href: "/faq" },
    ],
  },
  {
    title: "ABOUT",
    links: [
      { label: "Our Story", href: "/about" },
      { label: "Sustainability", href: "/sustainability" },
      { label: "Careers", href: "/careers" },
      { label: "Press", href: "/press" },
      { label: "Terms", href: "/terms" },
      { label: "Privacy", href: "/privacy" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="bg-noir border-t border-white/5 mt-24">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 py-16 md:py-20">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10 md:gap-12">
          <div className="col-span-2">
            <Link href="/" className="text-2xl font-black tracking-[-0.02em]">
              NOIR<span className="text-noir-500">//</span>STREET
            </Link>
            <p className="mt-5 text-sm text-noir-400 max-w-sm leading-relaxed">
              Premium streetwear built for the streets. Limited drops, uncompromising quality, timeless design.
            </p>
            <div className="flex gap-4 mt-6">
              <a href="#" className="text-noir-400 hover:text-bone transition-colors" aria-label="Instagram">{Icons.instagram}</a>
              <a href="#" className="text-noir-400 hover:text-bone transition-colors" aria-label="Youtube">{Icons.youtube}</a>
              <a href="#" className="text-noir-400 hover:text-bone transition-colors" aria-label="Twitter">{Icons.twitter}</a>
              <a href="#" className="text-noir-400 hover:text-bone transition-colors text-xs font-bold tracking-widest">TIKTOK</a>
            </div>
          </div>
          {GROUPS.map((g) => (
            <div key={g.title}>
              <h4 className="text-xs tracking-[0.25em] text-noir-500 mb-5">{g.title}</h4>
              <ul className="space-y-3">
                {g.links.map((l) => (
                  <li key={l.label}>
                    <Link
                      href={l.href}
                      className="text-sm text-noir-200 hover:text-bone transition-colors"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <p className="text-xs text-noir-500 tracking-widest">
            © {new Date().getFullYear()} NOIR//STREET. ALL RIGHTS RESERVED.
          </p>
          <div className="flex gap-6 text-xs text-noir-500 tracking-widest">
            <span>VISA</span>
            <span>MASTERCARD</span>
            <span>AMEX</span>
            <span>PAYPAL</span>
            <span>APPLE PAY</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
