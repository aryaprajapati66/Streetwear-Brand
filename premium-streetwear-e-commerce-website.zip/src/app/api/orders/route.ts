import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, customerName, address, city, postalCode, country, items } = body;
    if (!email || !items || !items.length) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    const subtotal = items.reduce(
      (sum: number, i: { price: number; quantity: number }) => sum + i.price * i.quantity,
      0
    );
    const shipping = subtotal > 150 ? 0 : 12;
    const total = subtotal + shipping;

    const session = await getSession();
    const [order] = await db
      .insert(orders)
      .values({
        userId: session?.id ?? null,
        email,
        customerName: customerName || email.split("@")[0],
        address,
        city,
        postalCode,
        country: country || "US",
        subtotal,
        shipping,
        total,
        items,
        status: "paid",
      })
      .returning();
    return NextResponse.json(order, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 400 });
  }
}

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json([]);
  if (session.isAdmin) {
    const all = await db.select().from(orders).orderBy(desc(orders.createdAt));
    return NextResponse.json(all);
  }
  const userOrders = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, session.id))
    .orderBy(desc(orders.createdAt));
  return NextResponse.json(userOrders);
}

export async function PATCH(req: Request) {
  const session = await getSession();
  if (!session?.isAdmin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id, status } = await req.json();
  if (!id || !status) return NextResponse.json({ error: "Missing" }, { status: 400 });
  const [updated] = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
  return NextResponse.json(updated);
}
