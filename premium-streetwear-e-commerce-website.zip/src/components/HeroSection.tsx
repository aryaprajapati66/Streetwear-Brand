import Link from "next/link";
import Image from "next/image";
import { ArrowRight } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative h-screen min-h-[640px] max-h-[1100px] overflow-hidden">
      {/* Background */}
      <Image
        src="/images/hero.jpg"
        alt="NOIR//STREET hero"
        fill
        className="object-cover animate-zoom-slow"
        priority
        quality={90}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-noir/50 via-noir/20 to-noir" />
      <div className="absolute inset-0 bg-gradient-to-r from-noir/80 via-noir/30 to-transparent" />

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-between">
        <div className="pt-28 md:pt-32 px-4 md:px-8">
          <div className="max-w-[1600px] mx-auto">
            <p className="text-[11px] md:text-xs tracking-[0.4em] text-bone/80 mb-4 animate-fade-in">
              COLLECTION 03 · FW26
            </p>
          </div>
        </div>

        <div className="flex-1 flex items-center">
          <div className="max-w-[1600px] mx-auto w-full px-4 md:px-8">
            <div className="max-w-3xl">
              <h1 className="text-[14vw] md:text-[10vw] lg:text-[8.5rem] font-black tracking-[-0.05em] leading-[0.85] animate-fade-in-up">
                BUILT FOR<br />
                THE <span className="italic font-light">STREETS.</span>
              </h1>
              <p className="text-base md:text-xl text-noir-200 mt-6 md:mt-8 max-w-xl leading-relaxed animate-fade-in-up delay-200">
                Limited pieces. Everyday attitude. Premium streetwear engineered for the city — from the sidewalk to the skyline.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 mt-8 md:mt-10 animate-fade-in-up delay-300">
                <Link
                  href="/shop?gender=men"
                  className="inline-flex items-center justify-center gap-3 bg-bone text-noir px-8 py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 transition-colors btn-press"
                >
                  SHOP MEN <ArrowRight size={14} />
                </Link>
                <Link
                  href="/shop?gender=women"
                  className="inline-flex items-center justify-center gap-3 border border-bone/80 text-bone px-8 py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone hover:text-noir transition-colors btn-press"
                >
                  SHOP WOMEN <ArrowRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom info bar */}
        <div className="pb-6 md:pb-10 px-4 md:px-8 animate-fade-in delay-500">
          <div className="max-w-[1600px] mx-auto flex items-end justify-between">
            <div className="text-[11px] tracking-[0.3em] text-noir-300 hidden md:block">
              SCROLL ↓
            </div>
            <div className="flex gap-8 md:gap-14 text-[11px] tracking-[0.3em] text-noir-300">
              <div>
                <div className="text-bone text-sm md:text-base font-bold mb-1">12+</div>
                NEW DROPS
              </div>
              <div>
                <div className="text-bone text-sm md:text-base font-bold mb-1">100%</div>
                PREMIUM
              </div>
              <div className="hidden md:block">
                <div className="text-bone text-sm md:text-base font-bold mb-1">WORLDWIDE</div>
                SHIPPING
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
