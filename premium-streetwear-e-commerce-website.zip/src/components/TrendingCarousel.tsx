"use client";

import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import ProductCard from "@/components/ProductCard";

type Product = {
  id: number;
  slug: string;
  name: string;
  price: number;
  compareAtPrice?: number | null;
  images: string[];
  rating: number;
  reviewCount: number;
  sizes: string[];
  category: string;
};

export default function TrendingCarousel({ products }: { products: Product[] }) {
  const ref = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    if (!ref.current) return;
    const el = ref.current;
    const amount = el.clientWidth * 0.8;
    el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  };

  return (
    <div className="relative">
      <button
        onClick={() => scroll("left")}
        className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-noir/80 backdrop-blur border border-white/10 items-center justify-center hover:bg-bone hover:text-noir transition-colors"
        aria-label="Previous"
      >
        <ChevronLeft size={20} />
      </button>
      <button
        onClick={() => scroll("right")}
        className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-noir/80 backdrop-blur border border-white/10 items-center justify-center hover:bg-bone hover:text-noir transition-colors"
        aria-label="Next"
      >
        <ChevronRight size={20} />
      </button>
      <div
        ref={ref}
        className="flex gap-4 md:gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory px-4 md:px-8 pb-4"
      >
        {products.map((p) => (
          <div key={p.id} className="snap-start shrink-0 w-[75%] sm:w-[45%] md:w-[30%] lg:w-[23%]">
            <ProductCard product={p} />
          </div>
        ))}
        <div className="shrink-0 w-8" />
      </div>
    </div>
  );
}
