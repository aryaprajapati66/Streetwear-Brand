import Link from "next/link";
import Image from "next/image";

const COLLECTIONS = [
  {
    name: "NEW DROP",
    slug: "New Drop",
    image: "https://images.unsplash.com/photo-1523398002811-999ca8dec234?w=1200&q=80&auto=format&fit=crop",
    tag: "JUST IN",
  },
  {
    name: "OVERSIZED TEES",
    slug: "Oversized Tees",
    image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1200&q=80&auto=format&fit=crop",
    tag: "ESSENTIALS",
  },
  {
    name: "HOODIES",
    slug: "Hoodies",
    image: "https://images.unsplash.com/photo-1578681994506-b8f463449011?w=1200&q=80&auto=format&fit=crop",
    tag: "HEAVYWEIGHT",
  },
  {
    name: "CARGO",
    slug: "Cargo",
    image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=1200&q=80&auto=format&fit=crop",
    tag: "UTILITY",
  },
  {
    name: "ACCESSORIES",
    slug: "Accessories",
    image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=1200&q=80&auto=format&fit=crop",
    tag: "FINISHING TOUCHES",
  },
];

export default function CollectionGrid() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 md:grid-rows-2 md:h-[720px]">
      {/* Large feature */}
      <Link
        href={`/shop?collection=${encodeURIComponent(COLLECTIONS[0].slug)}`}
        className="group relative col-span-2 row-span-2 aspect-[4/5] md:aspect-auto overflow-hidden bg-noir-800"
      >
        <Image
          src={COLLECTIONS[0].image}
          alt={COLLECTIONS[0].name}
          fill
          className="object-cover zoom-img"
          sizes="(max-width: 768px) 100vw, 50vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-noir/80 via-noir/20 to-transparent" />
        <div className="absolute bottom-0 left-0 p-5 md:p-8">
          <p className="text-[10px] tracking-[0.3em] text-bone/70 mb-2">{COLLECTIONS[0].tag}</p>
          <h3 className="text-3xl md:text-5xl font-black tracking-[-0.02em]">{COLLECTIONS[0].name}</h3>
          <div className="mt-3 text-xs tracking-[0.25em] text-bone/90 inline-flex items-center gap-2 border-b border-bone/40 pb-1 group-hover:border-bone transition-colors">
            EXPLORE →
          </div>
        </div>
      </Link>

      {/* Smaller tiles */}
      {COLLECTIONS.slice(1).map((c) => (
        <Link
          key={c.name}
          href={`/shop?collection=${encodeURIComponent(c.slug)}`}
          className="group relative aspect-[4/5] overflow-hidden bg-noir-800"
        >
          <Image
            src={c.image}
            alt={c.name}
            fill
            className="object-cover zoom-img"
            sizes="(max-width: 768px) 50vw, 25vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-noir/80 via-noir/20 to-transparent" />
          <div className="absolute bottom-0 left-0 p-4 md:p-5">
            <p className="text-[9px] md:text-[10px] tracking-[0.3em] text-bone/70 mb-1.5">{c.tag}</p>
            <h3 className="text-base md:text-lg font-bold tracking-[-0.01em]">{c.name}</h3>
          </div>
        </Link>
      ))}
    </div>
  );
}
