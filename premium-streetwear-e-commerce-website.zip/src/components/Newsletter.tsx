"use client";

import { useState, FormEvent } from "react";
import { ArrowRight, Check } from "lucide-react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [msg, setMsg] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error("Failed");
      setStatus("done");
      setMsg("Welcome to the drop. Check your inbox.");
      setEmail("");
    } catch {
      setStatus("error");
      setMsg("Something went wrong. Try again.");
    }
  };

  return (
    <section className="px-4 md:px-8 py-20 md:py-28 max-w-[1600px] mx-auto">
      <div className="border border-white/10 bg-noir-900 p-8 md:p-16 lg:p-20 relative overflow-hidden">
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] bg-noir-700/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative max-w-2xl">
          <p className="text-xs tracking-[0.3em] text-noir-500 mb-5">JOIN THE DROP</p>
          <h2 className="text-4xl md:text-6xl font-black tracking-[-0.03em] leading-[0.95] mb-6">
            FIRST ACCESS.<br />EVERY TIME.
          </h2>
          <p className="text-noir-300 text-base md:text-lg max-w-xl leading-relaxed mb-10">
            Subscribe to be first to know about new drops, exclusive releases, and private sales. No spam, ever.
          </p>
          <form onSubmit={submit} className="flex flex-col sm:flex-row gap-3 max-w-lg">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="flex-1 bg-transparent border border-white/15 px-5 py-4 text-sm focus:border-bone outline-none placeholder:text-noir-500"
            />
            <button
              type="submit"
              disabled={status === "loading"}
              className="bg-bone text-noir px-7 py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 transition-colors btn-press inline-flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {status === "loading" ? "SENDING..." : "SUBSCRIBE"}
              {status === "done" ? <Check size={14} /> : <ArrowRight size={14} />}
            </button>
          </form>
          {msg && (
            <p className={`mt-5 text-sm ${status === "error" ? "text-red-400" : "text-bone/80"}`}>
              {msg}
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
