import { Suspense } from "react";
import { db } from "@/db";
import { products } from "@/db/schema";
import { desc, eq, and, sql, like, or } from "drizzle-orm";
import ProductCard from "@/components/ProductCard";
import ShopFilters from "@/components/ShopFilters";

export const dynamic = "force-dynamic";

type SP = {
  category?: string;
  collection?: string;
  color?: string;
  size?: string;
  gender?: string;
  q?: string;
  sort?: string;
  new?: string;
  sale?: string;
  minPrice?: string;
  maxPrice?: string;
};

async function getShopProducts(sp: SP) {
  const conditions: ReturnType<typeof eq>[] = [];
  if (sp.category) conditions.push(eq(products.category, sp.category));
  if (sp.collection) conditions.push(eq(products.collection, sp.collection));
  if (sp.gender && sp.gender !== "all") conditions.push(eq(products.gender, sp.gender));
  if (sp.new === "1") conditions.push(eq(products.newArrival, true));
  if (sp.minPrice) conditions.push(sql`${products.price} >= ${parseFloat(sp.minPrice)}`);
  if (sp.maxPrice) conditions.push(sql`${products.price} <= ${parseFloat(sp.maxPrice)}`);
  if (sp.sale === "1") {
    conditions.push(sql`${products.compareAtPrice} IS NOT NULL`);
  }
  if (sp.color) {
    conditions.push(sql`${products.colors}::jsonb @> ${JSON.stringify([sp.color])}::jsonb`);
  }
  if (sp.size) {
    conditions.push(sql`${products.sizes}::jsonb @> ${JSON.stringify([sp.size])}::jsonb`);
  }
  if (sp.q) {
    const q = sp.q.toLowerCase();
    conditions.push(
      or(
        like(sql`lower(${products.name})`, `%${q}%`),
        like(sql`lower(${products.description})`, `%${q}%`)
      )!
    );
  }
  const where = conditions.length > 0 ? and(...conditions) : undefined;

  let orderBy: ReturnType<typeof desc>[];
  if (sp.sort === "price-asc") orderBy = [sql`${products.price} ASC`];
  else if (sp.sort === "price-desc") orderBy = [sql`${products.price} DESC`];
  else if (sp.sort === "popular") orderBy = [desc(products.reviewCount)];
  else orderBy = [desc(products.createdAt)];

  const rows = await db.select().from(products).where(where).orderBy(...orderBy).limit(60);
  return rows;
}

async function getFacets() {
  const all = await db.select({
    category: products.category,
    collection: products.collection,
    colors: products.colors,
    sizes: products.sizes,
  }).from(products);
  const categories = Array.from(new Set(all.map((r) => r.category))).sort();
  const collections = Array.from(new Set(all.map((r) => r.collection))).sort();
  const colors = Array.from(new Set(all.flatMap((r) => r.colors))).sort();
  const sizes = Array.from(new Set(all.flatMap((r) => r.sizes)));
  // stable size ordering
  const sizeOrder = ["XS", "S", "M", "L", "XL", "XXL", "ONE SIZE", "US 7", "US 8", "US 9", "US 10", "US 11", "US 12"];
  sizes.sort((a, b) => sizeOrder.indexOf(a) - sizeOrder.indexOf(b));
  return { categories, collections, colors, sizes };
}

export default async function ShopPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const [rows, facets] = await Promise.all([getShopProducts(sp), getFacets()]);

  const title = sp.collection || sp.category || (sp.new === "1" ? "New Arrivals" : sp.q ? `Search: ${sp.q}` : "All Products");

  return (
    <div className="pt-28 md:pt-32">
      {/* Header */}
      <div className="px-4 md:px-8 max-w-[1600px] mx-auto mb-10 md:mb-14">
        <p className="text-xs tracking-[0.3em] text-noir-500 mb-3">SHOP</p>
        <div className="flex items-end justify-between flex-wrap gap-6">
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-[-0.04em] leading-[0.9]">
            {String(title).toUpperCase()}
          </h1>
          <div className="text-sm text-noir-400">
            {rows.length} {rows.length === 1 ? "PRODUCT" : "PRODUCTS"}
          </div>
        </div>
      </div>

      <Suspense fallback={<ShopLoading />}>
        <ShopFilters facets={facets} current={sp} />
      </Suspense>

      <div className="px-4 md:px-8 max-w-[1600px] mx-auto py-6 md:py-10">
        {rows.length === 0 ? (
          <div className="py-24 text-center">
            <p className="text-xl text-noir-400 mb-3">No products found</p>
            <p className="text-sm text-noir-500">Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {rows.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ShopLoading() {
  return <div className="px-4 md:px-8 max-w-[1600px] mx-auto py-6 text-noir-500">Loading…</div>;
}
