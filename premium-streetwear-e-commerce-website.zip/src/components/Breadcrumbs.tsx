"use client";

import Link from "next/link";
import { ChevronRight } from "lucide-react";

type Product = {
  name: string;
  category: string;
  collection: string;
  slug: string;
};

export default function Breadcrumbs({ product }: { product: Product }) {
  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs tracking-[0.15em] text-noir-500">
      <Link href="/" className="hover:text-bone">HOME</Link>
      <ChevronRight size={12} />
      <Link href="/shop" className="hover:text-bone">SHOP</Link>
      <ChevronRight size={12} />
      <Link href={`/shop?collection=${encodeURIComponent(product.collection)}`} className="hover:text-bone">
        {product.collection.toUpperCase()}
      </Link>
      <ChevronRight size={12} />
      <span className="text-bone truncate max-w-[120px] md:max-w-none">{product.name}</span>
    </nav>
  );
}
