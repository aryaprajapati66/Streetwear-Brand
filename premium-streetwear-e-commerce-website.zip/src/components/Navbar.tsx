"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { ShoppingBag, Heart, User, Search, Menu, X } from "lucide-react";
import { useStore } from "@/lib/store";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const NAV = [
  { label: "SHOP", href: "/shop" },
  { label: "MEN", href: "/shop?gender=men" },
  { label: "WOMEN", href: "/shop?gender=women" },
  { label: "NEW", href: "/shop?new=1" },
  { label: "SALE", href: "/shop?sale=1" },
];

export default function Navbar() {
  const { count, isWishlisted, wishlist, user } = useStore();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const pathname = usePathname();
  const countNum = count();
  const wishCount = wishlist.length;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  return (
    <>
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-40 transition-all duration-500",
          scrolled || menuOpen || searchOpen
            ? "glass border-b border-white/5"
            : "bg-transparent"
        )}
      >
        <div className="max-w-[1600px] mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden p-2 -ml-2"
              aria-label="Menu"
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>

            <nav className="hidden md:flex items-center gap-8">
              {NAV.slice(0, 4).map((n) => (
                <Link
                  key={n.label}
                  href={n.href}
                  className="text-xs tracking-[0.2em] text-noir-200 hover:text-bone transition-colors relative group"
                >
                  {n.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-px bg-bone transition-all duration-300 group-hover:w-full" />
                </Link>
              ))}
            </nav>

            <Link
              href="/"
              className="text-base md:text-lg font-black tracking-[-0.02em] select-none"
            >
              NOIR<span className="text-noir-400">//</span>STREET
            </Link>

            <div className="flex items-center gap-1 md:gap-3">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 hover:text-white text-noir-200 transition-colors"
                aria-label="Search"
              >
                <Search size={18} />
              </button>
              <Link
                href="/profile"
                className="p-2 hidden md:block hover:text-white text-noir-200 transition-colors relative"
                aria-label="Account"
              >
                <User size={18} />
                {user && (
                  <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-bone rounded-full" />
                )}
              </Link>
              <Link
                href="/wishlist"
                className="p-2 hidden md:block hover:text-white text-noir-200 transition-colors relative"
                aria-label="Wishlist"
              >
                <Heart size={18} />
                {wishCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 text-[9px] bg-bone text-noir rounded-full w-4 h-4 flex items-center justify-center font-bold">
                    {wishCount}
                  </span>
                )}
              </Link>
              <Link
                href="/cart"
                className="p-2 hover:text-white text-noir-200 transition-colors relative"
                aria-label="Cart"
              >
                <ShoppingBag size={18} />
                {countNum > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 text-[9px] bg-bone text-noir rounded-full w-4 h-4 flex items-center justify-center font-bold">
                    {countNum}
                  </span>
                )}
              </Link>
            </div>
          </div>
        </div>

        {/* Search bar */}
        {searchOpen && (
          <div className="border-t border-white/5 animate-fade-in">
            <div className="max-w-[1600px] mx-auto px-4 md:px-8 py-4">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (query.trim()) {
                    window.location.href = `/shop?q=${encodeURIComponent(query)}`;
                  }
                }}
                className="flex items-center gap-3"
              >
                <Search size={18} className="text-noir-400" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search for products, collections..."
                  className="flex-1 bg-transparent border-none outline-none text-base md:text-lg placeholder:text-noir-500"
                />
                <button
                  type="button"
                  onClick={() => setSearchOpen(false)}
                  className="text-xs tracking-widest text-noir-400 hover:text-bone"
                >
                  CLOSE
                </button>
              </form>
            </div>
          </div>
        )}
      </header>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-30 bg-noir pt-20 md:hidden animate-fade-in">
          <nav className="flex flex-col px-6 py-8 gap-1">
            {NAV.map((n) => (
              <Link
                key={n.label}
                href={n.href}
                className="text-3xl font-black tracking-[-0.02em] py-3 border-b border-white/5 hover:text-bone"
              >
                {n.label}
              </Link>
            ))}
            <Link
              href="/profile"
              className="text-3xl font-black tracking-[-0.02em] py-3 border-b border-white/5 hover:text-bone"
            >
              ACCOUNT
            </Link>
            <Link
              href="/wishlist"
              className="text-3xl font-black tracking-[-0.02em] py-3 border-b border-white/5 hover:text-bone"
            >
              WISHLIST {wishCount > 0 && `(${wishCount})`}
            </Link>
          </nav>
        </div>
      )}
    </>
  );
}
