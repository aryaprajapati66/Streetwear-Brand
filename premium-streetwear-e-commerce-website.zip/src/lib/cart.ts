export type CartItem = {
  productId: number;
  name: string;
  slug: string;
  image: string;
  size: string;
  quantity: number;
  price: number;
};

const KEY = "noir_street_cart_v1";

export function getCart(): CartItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    return JSON.parse(raw) as CartItem[];
  } catch {
    return [];
  }
}

export function saveCart(items: CartItem[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(items));
  window.dispatchEvent(new CustomEvent("cart-updated", { detail: items }));
}

export function addToCart(item: Omit<CartItem, "quantity">, quantity = 1): CartItem[] {
  const cart = getCart();
  const idx = cart.findIndex(
    (c) => c.productId === item.productId && c.size === item.size
  );
  if (idx >= 0) {
    cart[idx].quantity += quantity;
  } else {
    cart.push({ ...item, quantity });
  }
  saveCart(cart);
  return cart;
}

export function updateQty(productId: number, size: string, quantity: number): CartItem[] {
  let cart = getCart();
  if (quantity <= 0) {
    cart = cart.filter((c) => !(c.productId === productId && c.size === size));
  } else {
    cart = cart.map((c) =>
      c.productId === productId && c.size === size ? { ...c, quantity } : c
    );
  }
  saveCart(cart);
  return cart;
}

export function removeFromCart(productId: number, size: string): CartItem[] {
  const cart = getCart().filter((c) => !(c.productId === productId && c.size === size));
  saveCart(cart);
  return cart;
}

export function clearCart() {
  saveCart([]);
}

export function cartSubtotal(cart: CartItem[]): number {
  return cart.reduce((sum, c) => sum + c.price * c.quantity, 0);
}

export function cartCount(cart: CartItem[]): number {
  return cart.reduce((sum, c) => sum + c.quantity, 0);
}

// Wishlist
const WISH_KEY = "noir_street_wishlist_v1";
export function getWishlist(): number[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(WISH_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}
export function toggleWishlist(productId: number): number[] {
  const list = getWishlist();
  const idx = list.indexOf(productId);
  const next = idx >= 0 ? list.filter((id) => id !== productId) : [...list, productId];
  if (typeof window !== "undefined") {
    localStorage.setItem(WISH_KEY, JSON.stringify(next));
    window.dispatchEvent(new CustomEvent("wishlist-updated", { detail: next }));
  }
  return next;
}
