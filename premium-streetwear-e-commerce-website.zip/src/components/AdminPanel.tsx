"use client";

import { useState, FormEvent } from "react";
import Image from "next/image";
import { Package, Users, ShoppingBag, DollarSign, Plus, Trash2, Edit2, X, Save } from "lucide-react";
import { formatPrice, slugify } from "@/lib/utils";

type Product = {
  id: number;
  slug: string;
  name: string;
  price: number;
  compareAtPrice: number | null;
  category: string;
  collection: string;
  colors: string[];
  sizes: string[];
  inventory: Record<string, number>;
  images: string[];
  description: string | null;
  materials: string | null;
  featured: boolean;
  newArrival: boolean;
  trending: boolean;
  gender: string;
};

type Order = {
  id: number;
  email: string;
  customerName: string;
  total: number;
  status: string;
  createdAt: string | Date;
  items: any[];
};

export default function AdminPanel({
  products,
  orders,
  users,
  revenue,
}: {
  products: Product[];
  orders: Order[];
  users: any[];
  revenue: number;
  user: any;
}) {
  const [tab, setTab] = useState<"overview" | "products" | "orders">("overview");
  const [productsList, setProductsList] = useState(products);
  const [ordersList, setOrdersList] = useState(orders);
  const [editing, setEditing] = useState<Product | null>(null);
  const [creating, setCreating] = useState(false);

  const deleteProduct = async (id: number) => {
    if (!confirm("Delete this product?")) return;
    await fetch(`/api/products?id=${id}`, { method: "DELETE" });
    setProductsList(productsList.filter((p) => p.id !== id));
  };

  const updateOrderStatus = async (id: number, status: string) => {
    await fetch("/api/orders", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status }),
    });
    setOrdersList(ordersList.map((o) => (o.id === id ? { ...o, status } : o)));
  };

  const saveProduct = async (data: any) => {
    if (editing) {
      const res = await fetch("/api/products", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, id: editing.id }),
      });
      const updated = await res.json();
      setProductsList(productsList.map((p) => (p.id === updated.id ? updated : p)));
    } else {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const created = await res.json();
      setProductsList([created, ...productsList]);
    }
    setEditing(null);
    setCreating(false);
  };

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8 py-8">
      <div className="mb-8">
        <p className="text-xs tracking-[0.3em] text-noir-500 mb-2">ADMIN DASHBOARD</p>
        <h1 className="text-3xl md:text-5xl font-black tracking-[-0.03em]">STORE MANAGEMENT</h1>
      </div>

      <div className="flex gap-1 border-b border-white/10 mb-8">
        {(["overview", "products", "orders"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-5 py-3 text-xs tracking-[0.2em] font-bold transition-colors ${
              tab === t ? "bg-bone text-noir" : "text-noir-400 hover:text-bone"
            }`}
          >
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          <StatCard icon={DollarSign} label="REVENUE" value={formatPrice(revenue)} />
          <StatCard icon={ShoppingBag} label="ORDERS" value={ordersList.length.toString()} />
          <StatCard icon={Package} label="PRODUCTS" value={productsList.length.toString()} />
          <StatCard icon={Users} label="USERS" value={users.length.toString()} />

          <div className="col-span-2 md:col-span-4 bg-noir-900 border border-white/10 p-6 mt-4">
            <h3 className="text-lg font-bold mb-4">Recent Orders</h3>
            <div className="space-y-3">
              {ordersList.slice(0, 5).map((o) => (
                <div key={o.id} className="flex items-center justify-between text-sm border-b border-white/5 pb-3">
                  <div>
                    <p className="font-medium">Order #{o.id}</p>
                    <p className="text-xs text-noir-500">{o.customerName} · {o.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{formatPrice(o.total)}</p>
                    <p className="text-xs tracking-[0.2em] text-noir-500 uppercase">{o.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === "products" && (
        <>
          <div className="flex justify-between items-center mb-6">
            <p className="text-noir-400">{productsList.length} products</p>
            <button
              onClick={() => { setCreating(true); setEditing(null); }}
              className="inline-flex items-center gap-2 bg-bone text-noir px-5 py-2.5 text-xs tracking-[0.2em] font-bold hover:bg-bone/90"
            >
              <Plus size={14} /> ADD PRODUCT
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {productsList.map((p) => (
              <div key={p.id} className="bg-noir-900 border border-white/10 p-4 flex gap-4">
                <div className="relative w-20 h-24 bg-noir-800 shrink-0">
                  {p.images[0] && <Image src={p.images[0]} alt={p.name} fill className="object-cover" sizes="80px" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] tracking-[0.2em] text-noir-500 mb-1">{p.category.toUpperCase()}</p>
                  <p className="font-bold text-sm truncate">{p.name}</p>
                  <p className="text-sm text-noir-400 mt-1">{formatPrice(p.price)}</p>
                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={() => { setEditing(p); setCreating(false); }}
                      className="p-1.5 border border-white/15 hover:border-bone"
                    >
                      <Edit2 size={12} />
                    </button>
                    <button
                      onClick={() => deleteProduct(p.id)}
                      className="p-1.5 border border-white/15 hover:border-red-500 text-red-400"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === "orders" && (
        <div className="bg-noir-900 border border-white/10">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 text-xs tracking-[0.2em] text-noir-500">
                <th className="text-left p-4">ORDER</th>
                <th className="text-left p-4">CUSTOMER</th>
                <th className="text-left p-4">TOTAL</th>
                <th className="text-left p-4">STATUS</th>
                <th className="text-left p-4">DATE</th>
                <th className="text-left p-4">ACTION</th>
              </tr>
            </thead>
            <tbody>
              {ordersList.map((o) => (
                <tr key={o.id} className="border-b border-white/5">
                  <td className="p-4 font-medium">#{o.id}</td>
                  <td className="p-4">
                    <p>{o.customerName}</p>
                    <p className="text-xs text-noir-500">{o.email}</p>
                  </td>
                  <td className="p-4 font-bold">{formatPrice(o.total)}</td>
                  <td className="p-4">
                    <span className="text-xs tracking-[0.2em] uppercase">{o.status}</span>
                  </td>
                  <td className="p-4 text-noir-400">
                    {new Date(o.createdAt).toLocaleDateString()}
                  </td>
                  <td className="p-4">
                    <select
                      value={o.status}
                      onChange={(e) => updateOrderStatus(o.id, e.target.value)}
                      className="bg-noir border border-white/15 px-2 py-1 text-xs"
                    >
                      <option value="pending">Pending</option>
                      <option value="paid">Paid</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {(creating || editing) && (
        <ProductEditor
          product={editing}
          onClose={() => { setEditing(null); setCreating(false); }}
          onSave={saveProduct}
        />
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="bg-noir-900 border border-white/10 p-5">
      <Icon size={20} className="text-noir-500 mb-3" />
      <p className="text-[10px] tracking-[0.3em] text-noir-500 mb-1">{label}</p>
      <p className="text-2xl font-black">{value}</p>
    </div>
  );
}

function ProductEditor({
  product,
  onClose,
  onSave,
}: {
  product: Product | null;
  onClose: () => void;
  onSave: (data: any) => void;
}) {
  const [form, setForm] = useState<{
    name: string;
    slug: string;
    description: string;
    price: number;
    compareAtPrice: number | null;
    category: string;
    collection: string;
    colors: string;
    sizes: string;
    images: string;
    materials: string;
    featured: boolean;
    newArrival: boolean;
    trending: boolean;
    gender: string;
  }>({
    name: product?.name || "",
    slug: product?.slug || "",
    description: product?.description || "",
    price: product?.price || 0,
    compareAtPrice: product?.compareAtPrice ?? null,
    category: product?.category || "Tees",
    collection: product?.collection || "New Drop",
    colors: product?.colors?.join(", ") || "",
    sizes: product?.sizes?.join(", ") || "S, M, L, XL",
    images: product?.images?.join(", ") || "",
    materials: product?.materials || "",
    featured: product?.featured || false,
    newArrival: product?.newArrival !== undefined ? product.newArrival : true,
    trending: product?.trending || false,
    gender: product?.gender || "unisex",
  });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const sizes = form.sizes.split(",").map((s) => s.trim()).filter(Boolean);
    const inventory: Record<string, number> = {};
    sizes.forEach((s) => { inventory[s] = 20; });
    onSave({
      ...form,
      slug: form.slug || slugify(form.name),
      colors: form.colors.split(",").map((c) => c.trim()).filter(Boolean),
      sizes,
      images: form.images.split(",").map((i) => i.trim()).filter(Boolean),
      inventory,
    });
  };

  return (
    <div className="fixed inset-0 bg-noir/90 backdrop-blur-sm z-50 overflow-y-auto p-4 md:p-8">
      <div className="max-w-2xl mx-auto bg-noir-900 border border-white/10 p-6 md:p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">{product ? "Edit" : "New"} Product</h2>
          <button onClick={onClose} className="p-2 hover:text-bone">
            <X size={18} />
          </button>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <input required placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
            <input placeholder="Slug" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} className="bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
            <input required type="number" step="0.01" placeholder="Price" value={form.price} onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) })} className="bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
            <input type="number" step="0.01" placeholder="Compare at price" value={form.compareAtPrice || ""} onChange={(e) => setForm({ ...form, compareAtPrice: e.target.value ? parseFloat(e.target.value) : null })} className="bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
            <input required placeholder="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
            <input required placeholder="Collection" value={form.collection} onChange={(e) => setForm({ ...form, collection: e.target.value })} className="bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
          </div>
          <input placeholder="Colors (comma separated)" value={form.colors} onChange={(e) => setForm({ ...form, colors: e.target.value })} className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
          <input placeholder="Sizes (comma separated)" value={form.sizes} onChange={(e) => setForm({ ...form, sizes: e.target.value })} className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
          <input placeholder="Image URLs (comma separated)" value={form.images} onChange={(e) => setForm({ ...form, images: e.target.value })} className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
          <textarea placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />
          <input placeholder="Materials" value={form.materials} onChange={(e) => setForm({ ...form, materials: e.target.value })} className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500" />

          <div className="flex gap-6 text-sm">
            <label className="inline-flex items-center gap-2"><input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} /> Featured</label>
            <label className="inline-flex items-center gap-2"><input type="checkbox" checked={form.newArrival} onChange={(e) => setForm({ ...form, newArrival: e.target.checked })} /> New Arrival</label>
            <label className="inline-flex items-center gap-2"><input type="checkbox" checked={form.trending} onChange={(e) => setForm({ ...form, trending: e.target.checked })} /> Trending</label>
          </div>

          <div className="flex gap-3 pt-4">
            <button type="submit" className="bg-bone text-noir px-6 py-3 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 inline-flex items-center gap-2">
              <Save size={14} /> SAVE
            </button>
            <button type="button" onClick={onClose} className="border border-white/15 px-6 py-3 text-xs tracking-[0.25em] font-bold hover:border-bone">
              CANCEL
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
