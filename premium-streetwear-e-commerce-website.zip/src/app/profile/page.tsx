"use client";

import { useState, FormEvent, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";
import { User, Package, LogOut } from "lucide-react";
import Link from "next/link";
import { formatPrice } from "@/lib/utils";

export default function ProfilePage() {
  const { user, refresh } = useStore();
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "signup" | "profile">(user ? "profile" : "login");
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({ email: "", password: "", name: "" });

  useEffect(() => {
    if (user) {
      setMode("profile");
      fetchOrders();
    }
  }, [user]);

  const fetchOrders = async () => {
    try {
      const res = await fetch("/api/orders");
      const data = await res.json();
      setOrders(data);
    } catch {
      setOrders([]);
    }
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: mode, ...form }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      await refresh();
      setMode("profile");
      setForm({ email: "", password: "", name: "" });
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "logout" }),
    });
    await refresh();
    setMode("login");
  };

  if (mode === "profile" && user) {
    return (
      <div className="pt-28 md:pt-32">
        <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-12">
          <div className="flex items-center justify-between mb-10">
            <div>
              <p className="text-xs tracking-[0.3em] text-noir-500 mb-2">WELCOME BACK</p>
              <h1 className="text-4xl md:text-5xl font-black tracking-[-0.03em]">{user.name || user.email}</h1>
            </div>
            <button
              onClick={logout}
              className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-noir-400 hover:text-bone"
            >
              <LogOut size={14} /> LOGOUT
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <div className="bg-noir-900 border border-white/10 p-6">
              <User size={24} className="text-noir-500 mb-3" />
              <h3 className="text-lg font-bold mb-2">Account</h3>
              <p className="text-sm text-noir-400">{user.email}</p>
              {user.isAdmin && (
                <Link
                  href="/admin"
                  className="inline-block mt-4 text-xs tracking-[0.2em] bg-bone text-noir px-4 py-2 font-bold hover:bg-bone/90"
                >
                  ADMIN DASHBOARD
                </Link>
              )}
            </div>
            <div className="bg-noir-900 border border-white/10 p-6">
              <Package size={24} className="text-noir-500 mb-3" />
              <h3 className="text-lg font-bold mb-2">Orders</h3>
              <p className="text-sm text-noir-400">{orders.length} order{orders.length !== 1 && "s"}</p>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">Order History</h2>
            {orders.length === 0 ? (
              <div className="bg-noir-900 border border-white/10 p-12 text-center">
                <Package size={32} className="mx-auto text-noir-500 mb-3" />
                <p className="text-noir-400">No orders yet</p>
                <Link href="/shop" className="inline-block mt-4 text-bone underline">
                  Start shopping
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order) => (
                  <div key={order.id} className="bg-noir-900 border border-white/10 p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <p className="text-xs tracking-[0.2em] text-noir-500 mb-1">
                          ORDER #{order.id}
                        </p>
                        <p className="text-sm text-noir-400">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold">{formatPrice(order.total)}</p>
                        <p className="text-xs tracking-[0.2em] text-noir-500 uppercase">{order.status}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {order.items.slice(0, 3).map((item: any, i: number) => (
                        <div key={i} className="flex items-center gap-3 text-sm">
                          <img src={item.image} alt={item.name} className="w-12 h-12 object-cover bg-noir-800" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{item.name}</p>
                            <p className="text-xs text-noir-500">{item.size} × {item.quantity}</p>
                          </div>
                        </div>
                      ))}
                      {order.items.length > 3 && (
                        <p className="text-xs text-noir-500">+{order.items.length - 3} more</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28 md:pt-32 min-h-[80vh] flex items-center">
      <div className="max-w-md mx-auto w-full px-4 md:px-8">
        <h1 className="text-4xl md:text-5xl font-black tracking-[-0.03em] mb-2">
          {mode === "login" ? "SIGN IN" : "CREATE ACCOUNT"}
        </h1>
        <p className="text-noir-400 mb-8">
          {mode === "login" ? "Welcome back." : "Join the community."}
        </p>

        <form onSubmit={submit} className="space-y-4">
          {mode === "signup" && (
            <input
              type="text"
              placeholder="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500"
            />
          )}
          <input
            type="email"
            required
            placeholder="Email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500"
          />
          <input
            type="password"
            required
            placeholder="Password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="w-full bg-transparent border border-white/15 px-4 py-3 text-sm focus:border-bone outline-none placeholder:text-noir-500"
          />
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-bone text-noir py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 transition-colors btn-press disabled:opacity-60"
          >
            {loading ? "..." : mode === "login" ? "SIGN IN" : "CREATE ACCOUNT"}
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-noir-400">
          {mode === "login" ? (
            <>
              Don't have an account?{" "}
              <button onClick={() => setMode("signup")} className="text-bone underline">
                Sign up
              </button>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <button onClick={() => setMode("login")} className="text-bone underline">
                Sign in
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
