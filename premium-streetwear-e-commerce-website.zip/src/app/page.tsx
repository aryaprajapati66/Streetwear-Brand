import Link from "next/link";
import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { db } from "@/db";
import { products } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import ProductCard from "@/components/ProductCard";
import { seed } from "@/lib/seed";
import HeroSection from "@/components/HeroSection";
import CollectionGrid from "@/components/CollectionGrid";
import TrendingCarousel from "@/components/TrendingCarousel";
import BrandStory from "@/components/BrandStory";
import Newsletter from "@/components/Newsletter";

export const revalidate = 60;

async function getProducts() {
  try {
    await seed();
  } catch {
    // ignore
  }

  const [newArrivals, trending, featured] = await Promise.all([
    db.select().from(products).where(eq(products.newArrival, true)).orderBy(desc(products.createdAt)).limit(8),
    db.select().from(products).where(eq(products.trending, true)).orderBy(desc(products.reviewCount)).limit(12),
    db.select().from(products).where(eq(products.featured, true)).orderBy(desc(products.createdAt)).limit(4),
  ]);

  return { newArrivals, trending, featured };
}

export default async function HomePage() {
  const { newArrivals, trending, featured } = await getProducts();

  return (
    <>
      <HeroSection />

      {/* Collections grid */}
      <section className="px-4 md:px-8 py-20 md:py-28 max-w-[1600px] mx-auto">
        <div className="flex items-end justify-between mb-10 md:mb-14">
          <div>
            <p className="text-xs tracking-[0.25em] text-noir-500 mb-3">SHOP BY</p>
            <h2 className="text-4xl md:text-6xl font-black tracking-[-0.03em]">
              FEATURED<br />COLLECTIONS
            </h2>
          </div>
          <Link
            href="/shop"
            className="hidden md:inline-flex items-center gap-2 text-xs tracking-[0.2em] text-noir-300 hover:text-bone transition-colors group"
          >
            VIEW ALL
            <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <CollectionGrid />
      </section>

      {/* New arrivals */}
      <section className="px-4 md:px-8 py-16 md:py-24 max-w-[1600px] mx-auto">
        <div className="flex items-end justify-between mb-10 md:mb-14">
          <div>
            <p className="text-xs tracking-[0.25em] text-noir-500 mb-3">JUST DROPPED</p>
            <h2 className="text-4xl md:text-6xl font-black tracking-[-0.03em]">NEW ARRIVALS</h2>
          </div>
          <Link
            href="/shop?new=1"
            className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-noir-300 hover:text-bone transition-colors group"
          >
            SHOP ALL
            <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {newArrivals.slice(0, 8).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Campaign */}
      <section className="relative h-[70vh] md:h-[90vh] overflow-hidden my-16 md:my-28">
        <Image
          src="/images/campaign.jpg"
          alt="Campaign"
          fill
          className="object-cover animate-zoom-slow"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-noir via-noir/40 to-transparent" />
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-[1600px] mx-auto w-full px-4 md:px-8 pb-12 md:pb-20">
            <p className="text-xs tracking-[0.3em] text-noir-300 mb-4 animate-fade-in">CAMPAIGN 03</p>
            <h2 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-[-0.04em] leading-[0.9] max-w-4xl animate-fade-in-up">
              THE CITY IS<br />YOUR RUNWAY.
            </h2>
            <Link
              href="/shop?collection=New Drop"
              className="inline-flex items-center gap-3 mt-8 md:mt-12 bg-bone text-noir px-8 py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 transition-colors btn-press animate-fade-in-up delay-300"
            >
              EXPLORE COLLECTION
              <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="py-16 md:py-24">
        <div className="px-4 md:px-8 max-w-[1600px] mx-auto mb-10 md:mb-14">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-xs tracking-[0.25em] text-noir-500 mb-3">TRENDING NOW</p>
              <h2 className="text-4xl md:text-6xl font-black tracking-[-0.03em]">
                MOST WANTED
              </h2>
            </div>
            <Link
              href="/shop"
              className="hidden md:inline-flex items-center gap-2 text-xs tracking-[0.2em] text-noir-300 hover:text-bone transition-colors"
            >
              SEE MORE <ArrowRight size={14} />
            </Link>
          </div>
        </div>
        <TrendingCarousel products={trending} />
      </section>

      {/* Brand story */}
      <BrandStory />

      {/* Newsletter */}
      <Newsletter />
    </>
  );
}
