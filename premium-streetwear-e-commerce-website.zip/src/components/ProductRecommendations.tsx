import { db } from "@/db";
import { products } from "@/db/schema";
import { and, eq, ne, desc } from "drizzle-orm";
import ProductCard from "@/components/ProductCard";

export default async function ProductRecommendations({
  category,
  excludeId,
}: {
  category: string;
  excludeId: number;
}) {
  const recs = await db
    .select()
    .from(products)
    .where(and(eq(products.category, category), ne(products.id, excludeId)))
    .orderBy(desc(products.reviewCount))
    .limit(4);

  if (recs.length === 0) return null;

  return (
    <section className="px-4 md:px-8 py-20 md:py-28 max-w-[1600px] mx-auto">
      <div className="mb-10 md:mb-14">
        <p className="text-xs tracking-[0.25em] text-noir-500 mb-3">YOU MAY ALSO LIKE</p>
        <h2 className="text-3xl md:text-5xl font-black tracking-[-0.03em]">COMPLETE THE LOOK</h2>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {recs.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
