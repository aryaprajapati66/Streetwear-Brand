import Image from "next/image";

export default function BrandStory() {
  return (
    <section className="bg-noir-900 border-y border-white/5 py-20 md:py-32">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 grid md:grid-cols-2 gap-12 md:gap-20 items-center">
        <div className="relative aspect-[4/5] bg-noir-800 overflow-hidden">
          <Image
            src="/images/brand.jpg"
            alt="NOIR//STREET studio"
            fill
            className="object-cover"
          />
        </div>
        <div>
          <p className="text-xs tracking-[0.3em] text-noir-500 mb-6">THE STORY</p>
          <h2 className="text-4xl md:text-6xl font-black tracking-[-0.03em] leading-[0.95] mb-8">
            NOT JUST<br />CLOTHES.<br />
            <span className="italic font-light text-noir-300">A STATEMENT.</span>
          </h2>
          <div className="space-y-5 text-noir-200 leading-relaxed max-w-lg">
            <p>
              Born from the streets, refined in the studio. NOIR//STREET began in 2021 as a quiet
              rebellion against fast fashion — a commitment to fewer, better pieces built to outlast
              trends and seasons.
            </p>
            <p>
              Every garment is designed in-house, manufactured in limited runs, and cut from premium
              materials. No excess inventory. No compromise. Just honest streetwear that moves with
              you — from the concrete to the boardroom.
            </p>
            <p className="text-bone font-medium">
              This is clothing with conviction.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-6 mt-10 pt-10 border-t border-white/10">
            <div>
              <div className="text-3xl md:text-4xl font-black">2021</div>
              <div className="text-[10px] tracking-[0.3em] text-noir-500 mt-2">ESTABLISHED</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-black">40+</div>
              <div className="text-[10px] tracking-[0.3em] text-noir-500 mt-2">COUNTRIES</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-black">12K</div>
              <div className="text-[10px] tracking-[0.3em] text-noir-500 mt-2">COMMUNITY</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
