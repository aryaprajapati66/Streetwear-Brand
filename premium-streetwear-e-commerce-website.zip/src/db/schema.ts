import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
  real,
  varchar,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    name: text("name"),
    isAdmin: boolean("is_admin").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => ({
    emailIdx: uniqueIndex("users_email_idx").on(t.email),
  })
);

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    price: real("price").notNull(),
    compareAtPrice: real("compare_at_price"),
    category: text("category").notNull(),
    collection: text("collection").notNull(),
    colors: jsonb("colors").$type<string[]>().default([]).notNull(),
    sizes: jsonb("sizes").$type<string[]>().default([]).notNull(),
    inventory: jsonb("inventory").$type<Record<string, number>>().default({}).notNull(),
    images: jsonb("images").$type<string[]>().default([]).notNull(),
    rating: real("rating").default(4.5).notNull(),
    reviewCount: integer("review_count").default(0).notNull(),
    featured: boolean("featured").default(false).notNull(),
    newArrival: boolean("new_arrival").default(false).notNull(),
    trending: boolean("trending").default(false).notNull(),
    materials: text("materials"),
    gender: text("gender").default("unisex").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => ({
    slugIdx: uniqueIndex("products_slug_idx").on(t.slug),
    catIdx: index("products_cat_idx").on(t.category),
    collIdx: index("products_coll_idx").on(t.collection),
  })
);

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  email: text("email").notNull(),
  customerName: text("customer_name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  postalCode: text("postal_code").notNull(),
  country: text("country").default("US").notNull(),
  subtotal: real("subtotal").notNull(),
  shipping: real("shipping").notNull(),
  total: real("total").notNull(),
  status: text("status").default("pending").notNull(),
  items: jsonb("items")
    .$type<Array<{
      productId: number;
      name: string;
      slug: string;
      image: string;
      size: string;
      quantity: number;
      price: number;
    }>>()
    .default([])
    .notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const wishlists = pgTable(
  "wishlists",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id),
    sessionId: text("session_id"),
    productId: integer("product_id")
      .references(() => products.id, { onDelete: "cascade" })
      .notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => ({
    userProdIdx: index("wishlists_user_prod_idx").on(t.userId, t.productId),
  })
);

export const newsletter = pgTable(
  "newsletter",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => ({
    emailIdx: uniqueIndex("newsletter_email_idx").on(t.email),
  })
);
