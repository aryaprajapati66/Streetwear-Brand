import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Providers from "@/components/Providers";
import AnnouncementBar from "@/components/AnnouncementBar";

export const metadata: Metadata = {
  title: {
    default: "NOIR//STREET — Premium Streetwear",
    template: "%s · NOIR//STREET",
  },
  description:
    "NOIR//STREET — limited drops, uncompromising quality, timeless design. Premium modern streetwear built for the streets.",
  keywords: ["streetwear", "premium streetwear", "hoodies", "cargo", "oversized", "NOIR STREET"],
  metadataBase: new URL("https://noirstreet.example"),
  openGraph: {
    type: "website",
    siteName: "NOIR//STREET",
    title: "NOIR//STREET — Premium Streetwear",
    description: "Limited drops. Uncompromising quality.",
  },
  twitter: {
    card: "summary_large_image",
    title: "NOIR//STREET",
    description: "Premium streetwear. Limited drops.",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-noir text-bone antialiased font-display">
        <Providers>
          <a
            href="#main"
            className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:bg-bone focus:text-noir focus:px-3 focus:py-2"
          >
            Skip to content
          </a>
          <AnnouncementBar />
          <Navbar />
          <main id="main" className="min-h-screen">{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
