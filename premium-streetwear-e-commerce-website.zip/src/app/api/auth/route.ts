import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword, setSession, clearSession, getSession, getUserByEmail } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { action, email, password, name } = await req.json();

  if (action === "signup") {
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password required" }, { status: 400 });
    }
    const existing = await getUserByEmail(email);
    if (existing) {
      return NextResponse.json({ error: "Email already registered" }, { status: 409 });
    }
    const passwordHash = await hashPassword(password);
    const [user] = await db
      .insert(users)
      .values({ email, passwordHash, name: name || null, isAdmin: false })
      .returning();
    await setSession({ id: user.id, email: user.email, name: user.name, isAdmin: user.isAdmin });
    return NextResponse.json({ user: { id: user.id, email: user.email, name: user.name, isAdmin: user.isAdmin } });
  }

  if (action === "login") {
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password required" }, { status: 400 });
    }
    const user = await getUserByEmail(email);
    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }
    const ok = await verifyPassword(password, user.passwordHash);
    if (!ok) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }
    await setSession({ id: user.id, email: user.email, name: user.name, isAdmin: user.isAdmin });
    return NextResponse.json({ user: { id: user.id, email: user.email, name: user.name, isAdmin: user.isAdmin } });
  }

  if (action === "logout") {
    await clearSession();
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ user: null });
  return NextResponse.json({ user: session });
}
