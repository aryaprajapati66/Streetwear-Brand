"use client";

import { useState, useEffect, createContext, useContext, ReactNode, useCallback } from "react";
import {
  getCart,
  saveCart,
  addToCart as addItem,
  updateQty,
  removeFromCart as removeItem,
  clearCart,
  cartSubtotal,
  cartCount,
  getWishlist,
  toggleWishlist,
  type CartItem,
} from "@/lib/cart";

type SessionUser = {
  id: number;
  email: string;
  name: string | null;
  isAdmin: boolean;
};

type Store = {
  cart: CartItem[];
  wishlist: number[];
  user: SessionUser | null;
  addToCart: (item: Omit<CartItem, "quantity">, qty?: number) => void;
  updateQuantity: (productId: number, size: string, qty: number) => void;
  removeFromCart: (productId: number, size: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: number) => void;
  isWishlisted: (productId: number) => boolean;
  subtotal: () => number;
  count: () => number;
  refresh: () => Promise<void>;
  setUser: (u: SessionUser | null) => void;
};

const StoreContext = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [user, setUser] = useState<SessionUser | null>(null);

  const refresh = useCallback(async () => {
    if (typeof window !== "undefined") {
      setCart(getCart());
      setWishlist(getWishlist());
    }
    try {
      const res = await fetch("/api/auth");
      const data = await res.json();
      setUser(data.user ?? null);
    } catch {
      setUser(null);
    }
  }, []);

  useEffect(() => {
    refresh();
    const onCart = (e: Event) => {
      const ce = e as CustomEvent<CartItem[]>;
      setCart(ce.detail || []);
    };
    const onWish = (e: Event) => {
      const we = e as CustomEvent<number[]>;
      setWishlist(we.detail || []);
    };
    window.addEventListener("cart-updated", onCart);
    window.addEventListener("wishlist-updated", onWish);
    return () => {
      window.removeEventListener("cart-updated", onCart);
      window.removeEventListener("wishlist-updated", onWish);
    };
  }, [refresh]);

  const value: Store = {
    cart,
    wishlist,
    user,
    setUser,
    addToCart: (item, qty) => {
      const next = addItem(item, qty);
      setCart(next);
    },
    updateQuantity: (pid, size, qty) => {
      const next = updateQty(pid, size, qty);
      setCart(next);
    },
    removeFromCart: (pid, size) => {
      const next = removeItem(pid, size);
      setCart(next);
    },
    clearCart: () => {
      clearCart();
      setCart([]);
    },
    toggleWishlist: (pid) => {
      const next = toggleWishlist(pid);
      setWishlist(next);
    },
    isWishlisted: (pid) => wishlist.includes(pid),
    subtotal: () => cartSubtotal(cart),
    count: () => cartCount(cart),
    refresh,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
