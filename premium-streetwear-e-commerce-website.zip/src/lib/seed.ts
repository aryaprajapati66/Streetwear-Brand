import { db } from "@/db";
import { products, users } from "@/db/schema";
import { sql } from "drizzle-orm";
import bcrypt from "bcryptjs";

// High-quality stock image URLs for streetwear products
const IMG = {
  hoodie1: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1200&q=80&auto=format&fit=crop",
  hoodie2: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=1200&q=80&auto=format&fit=crop",
  tee1: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1200&q=80&auto=format&fit=crop",
  tee2: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=1200&q=80&auto=format&fit=crop",
  tee3: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1200&q=80&auto=format&fit=crop",
  cargo1: "https://images.unsplash.com/photo-1551854838-212c9a5e71b4?w=1200&q=80&auto=format&fit=crop",
  cargo2: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=1200&q=80&auto=format&fit=crop",
  jacket1: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1200&q=80&auto=format&fit=crop",
  jacket2: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=1200&q=80&auto=format&fit=crop",
  cap1: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=1200&q=80&auto=format&fit=crop",
  bag1: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=1200&q=80&auto=format&fit=crop",
  shoe1: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&q=80&auto=format&fit=crop",
  shoe2: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=1200&q=80&auto=format&fit=crop",
  pants1: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=1200&q=80&auto=format&fit=crop",
  shorts1: "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=1200&q=80&auto=format&fit=crop",
};

const SIZES = ["XS", "S", "M", "L", "XL", "XXL"];
const APPAREL_SIZES = ["S", "M", "L", "XL", "XXL"];
const SHOE_SIZES = ["US 7", "US 8", "US 9", "US 10", "US 11", "US 12"];

function makeInventory(sizes: string[], base = 24): Record<string, number> {
  const inv: Record<string, number> = {};
  sizes.forEach((s, i) => {
    inv[s] = base + (i % 5) * 4;
  });
  return inv;
}

const SEED_PRODUCTS = [
  {
    slug: "shadow-oversized-hoodie-black",
    name: "SHADOW OVERSIZED HOODIE",
    description: "Heavyweight 450gsm cotton fleece hoodie with a drop shoulder silhouette and raw-edge hem. Embroidered tonal NOIR//STREET wordmark across the back. Cut to be oversized — size down for a closer fit.",
    price: 148,
    compareAtPrice: 180,
    category: "Hoodies",
    collection: "New Drop",
    colors: ["Black", "Washed Charcoal"],
    sizes: APPAREL_SIZES,
    images: [IMG.hoodie1, IMG.hoodie2],
    rating: 4.8,
    reviewCount: 142,
    featured: true,
    newArrival: true,
    trending: true,
    materials: "100% Organic Cotton Fleece, 450gsm",
    gender: "unisex",
  },
  {
    slug: "concrete-washed-tee",
    name: "CONCRETE WASHED TEE",
    description: "Acid-washed boxy tee with a raw-cut neck and dropped shoulders. Garment-dyed for a lived-in vintage feel.",
    price: 68,
    category: "Tees",
    collection: "Oversized Tees",
    colors: ["Concrete", "Bone", "Obsidian"],
    sizes: APPAREL_SIZES,
    images: [IMG.tee1, IMG.tee2, IMG.tee3],
    rating: 4.7,
    reviewCount: 89,
    featured: true,
    newArrival: true,
    trending: false,
    materials: "100% Cotton, 240gsm, enzyme washed",
    gender: "unisex",
  },
  {
    slug: "midnight-essential-tee",
    name: "MIDNIGHT ESSENTIAL TEE",
    description: "Our everyday heavyweight tee with a boxy fit and subtle embroidered chest logo. Cut for layering.",
    price: 58,
    category: "Tees",
    collection: "Oversized Tees",
    colors: ["Black", "White", "Grey"],
    sizes: APPAREL_SIZES,
    images: [IMG.tee2, IMG.tee3],
    rating: 4.9,
    reviewCount: 211,
    featured: false,
    newArrival: false,
    trending: true,
    materials: "100% Cotton, 220gsm",
    gender: "unisex",
  },
  {
    slug: "gridline-cargo-pants",
    name: "GRIDLINE CARGO PANTS",
    description: "Utility-forward cargo trousers with oversized pockets, articulated knees, and adjustable ankle cuffs. Made from a durable ripstop cotton.",
    price: 168,
    category: "Pants",
    collection: "Cargo",
    colors: ["Black", "Olive", "Stone"],
    sizes: APPAREL_SIZES,
    images: [IMG.cargo1, IMG.cargo2, IMG.pants1],
    rating: 4.6,
    reviewCount: 74,
    featured: true,
    newArrival: true,
    trending: true,
    materials: "Ripstop Cotton / Nylon blend",
    gender: "unisex",
  },
  {
    slug: "asphalt-bomber-jacket",
    name: "ASPHALT BOMBER JACKET",
    description: "Technical bomber jacket with a matte water-resistant shell, quilted lining, and ribbed cuffs. A modern classic for the streets.",
    price: 298,
    compareAtPrice: 340,
    category: "Outerwear",
    collection: "New Drop",
    colors: ["Black", "Midnight Navy"],
    sizes: APPAREL_SIZES,
    images: [IMG.jacket1, IMG.jacket2],
    rating: 4.9,
    reviewCount: 56,
    featured: true,
    newArrival: true,
    trending: false,
    materials: "Water-resistant nylon shell, recycled polyester lining",
    gender: "unisex",
  },
  {
    slug: "monolith-crewneck-sweat",
    name: "MONOLITH CREWNECK SWEAT",
    description: "Heavyweight crewneck sweatshirt with puff-printed back logo. Relaxed fit with ribbed cuffs.",
    price: 128,
    category: "Hoodies",
    collection: "New Drop",
    colors: ["Black", "Heather Grey", "Cream"],
    sizes: APPAREL_SIZES,
    images: [IMG.hoodie2, IMG.tee3],
    rating: 4.7,
    reviewCount: 103,
    featured: false,
    newArrival: false,
    trending: true,
    materials: "100% Cotton Fleece, 420gsm",
    gender: "unisex",
  },
  {
    slug: "district-utility-shorts",
    name: "DISTRICT UTILITY SHORTS",
    description: "Knee-length cargo shorts with oversized 3D pockets and adjustable drawcord waist.",
    price: 98,
    category: "Shorts",
    collection: "Cargo",
    colors: ["Black", "Khaki"],
    sizes: APPAREL_SIZES,
    images: [IMG.shorts1, IMG.cargo2],
    rating: 4.5,
    reviewCount: 41,
    featured: false,
    newArrival: true,
    trending: false,
    materials: "Cotton twill",
    gender: "unisex",
  },
  {
    slug: "signal-runner-v2",
    name: "SIGNAL RUNNER V2",
    description: "Technical low-top sneaker with a chunky sole, mesh upper and signature monochrome palette. Built for city streets.",
    price: 189,
    category: "Footwear",
    collection: "New Drop",
    colors: ["Black/White", "Triple Black"],
    sizes: SHOE_SIZES,
    images: [IMG.shoe1, IMG.shoe2],
    rating: 4.8,
    reviewCount: 178,
    featured: true,
    newArrival: true,
    trending: true,
    materials: "Mesh / Synthetic leather / EVA sole",
    gender: "unisex",
  },
  {
    slug: "void-panelled-hoodie",
    name: "VOID PANELLED HOODIE",
    description: "Deconstructed hoodie with contrast panelling, exposed seams, and adjustable drawcord hood.",
    price: 158,
    category: "Hoodies",
    collection: "New Drop",
    colors: ["Black", "Charcoal"],
    sizes: APPAREL_SIZES,
    images: [IMG.hoodie1, IMG.hoodie2],
    rating: 4.6,
    reviewCount: 62,
    featured: false,
    newArrival: true,
    trending: false,
    materials: "Cotton/Poly blend fleece",
    gender: "unisex",
  },
  {
    slug: "block-5-panel-cap",
    name: "BLOCK 5-PANEL CAP",
    description: "Unstructured 5-panel cap with embroidered front logo and adjustable nylon strap.",
    price: 48,
    category: "Accessories",
    collection: "Accessories",
    colors: ["Black", "Cream", "Navy"],
    sizes: ["ONE SIZE"],
    images: [IMG.cap1],
    rating: 4.7,
    reviewCount: 94,
    featured: false,
    newArrival: false,
    trending: true,
    materials: "Cotton canvas",
    gender: "unisex",
  },
  {
    slug: "transit-shoulder-bag",
    name: "TRANSIT SHOULDER BAG",
    description: "Compact shoulder bag with water-resistant shell, multiple compartments and adjustable crossbody strap.",
    price: 78,
    category: "Accessories",
    collection: "Accessories",
    colors: ["Black"],
    sizes: ["ONE SIZE"],
    images: [IMG.bag1],
    rating: 4.8,
    reviewCount: 53,
    featured: false,
    newArrival: true,
    trending: false,
    materials: "Recycled nylon",
    gender: "unisex",
  },
  {
    slug: "fracture-graphic-tee",
    name: "FRACTURE GRAPHIC TEE",
    description: "Oversized graphic tee with screen-printed back artwork. Heavyweight cotton with a raw-cut neckline.",
    price: 72,
    category: "Tees",
    collection: "Oversized Tees",
    colors: ["Black", "White"],
    sizes: APPAREL_SIZES,
    images: [IMG.tee3, IMG.tee1],
    rating: 4.6,
    reviewCount: 67,
    featured: false,
    newArrival: false,
    trending: true,
    materials: "100% Cotton, 260gsm",
    gender: "unisex",
  },
];

export async function seed() {
  // Seed products
  const existing = await db.select({ count: sql<number>`count(*)::int` }).from(products);
  if (existing[0]?.count === 0) {
    await db.insert(products).values(
      SEED_PRODUCTS.map((p) => ({
        ...p,
        inventory: makeInventory(p.sizes, 20),
      }))
    );
    console.log(`[seed] Inserted ${SEED_PRODUCTS.length} products`);
  } else {
    console.log(`[seed] Products already exist, skipping`);
  }

  // Seed admin user
  const adminEmail = "admin@noirstreet.com";
  const existingAdmin = await db.query.users.findFirst({
    where: (u, { eq }) => eq(u.email, adminEmail),
  });
  if (!existingAdmin) {
    const hash = await bcrypt.hash("admin123", 10);
    await db.insert(users).values({
      email: adminEmail,
      passwordHash: hash,
      name: "Admin",
      isAdmin: true,
    });
    console.log("[seed] Created admin user: admin@noirstreet.com / admin123");
  }
}
