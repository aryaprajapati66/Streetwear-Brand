import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { db } from "@/db";
import { products, orders, users } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import AdminPanel from "@/components/AdminPanel";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const session = await getSession();
  if (!session?.isAdmin) redirect("/profile");

  const [productRows, orderRows, userRows] = await Promise.all([
    db.select().from(products).orderBy(desc(products.createdAt)),
    db.select().from(orders).orderBy(desc(orders.createdAt)),
    db.select().from(users).orderBy(desc(users.createdAt)),
  ]);

  const stats = await Promise.all([
    db.select({ count: sql<number>`count(*)::int`, total: sql<number>`coalesce(sum(total), 0)::float` }).from(orders),
  ]);

  return (
    <div className="pt-28 md:pt-32">
      <AdminPanel
        products={productRows}
        orders={orderRows}
        users={userRows}
        revenue={stats[0][0]?.total || 0}
        user={session}
      />
    </div>
  );
}
