import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq, desc, asc, sql, and, like, or } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category");
  const collection = searchParams.get("collection");
  const color = searchParams.get("color");
  const size = searchParams.get("size");
  const gender = searchParams.get("gender");
  const search = searchParams.get("q");
  const sort = searchParams.get("sort") || "newest";
  const featured = searchParams.get("featured");
  const newArrival = searchParams.get("new");
  const trending = searchParams.get("trending");
  const slug = searchParams.get("slug");
  const minPrice = searchParams.get("minPrice");
  const maxPrice = searchParams.get("maxPrice");
  const limitParam = searchParams.get("limit");
  const limit = limitParam ? parseInt(limitParam, 10) : 60;

  if (slug) {
    const [product] = await db
      .select()
      .from(products)
      .where(eq(products.slug, slug));
    if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(product);
  }

  const conditions: ReturnType<typeof eq>[] = [];
  if (category) conditions.push(eq(products.category, category));
  if (collection) conditions.push(eq(products.collection, collection));
  if (gender && gender !== "all") conditions.push(eq(products.gender, gender));
  if (featured === "1") conditions.push(eq(products.featured, true));
  if (newArrival === "1") conditions.push(eq(products.newArrival, true));
  if (trending === "1") conditions.push(eq(products.trending, true));
  if (minPrice) conditions.push(sql`${products.price} >= ${parseFloat(minPrice)}`);
  if (maxPrice) conditions.push(sql`${products.price} <= ${parseFloat(maxPrice)}`);

  // JSON array contains for color/size
  if (color) {
    conditions.push(sql`${products.colors}::jsonb @> ${JSON.stringify([color])}::jsonb`);
  }
  if (size) {
    conditions.push(sql`${products.sizes}::jsonb @> ${JSON.stringify([size])}::jsonb`);
  }
  if (search) {
    conditions.push(
      or(
        like(sql`lower(${products.name})`, `%${search.toLowerCase()}%`),
        like(sql`lower(${products.description})`, `%${search.toLowerCase()}%`)
      )!
    );
  }

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  let orderBy: Parameters<typeof db.select>[0] extends never ? never : ReturnType<typeof desc>[];
  if (sort === "price-asc") orderBy = [asc(products.price)];
  else if (sort === "price-desc") orderBy = [desc(products.price)];
  else if (sort === "popular") orderBy = [desc(products.reviewCount)];
  else orderBy = [desc(products.createdAt)];

  const rows = await db
    .select()
    .from(products)
    .where(where)
    .orderBy(...orderBy)
    .limit(limit);

  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const [created] = await db.insert(products).values(body).returning();
    return NextResponse.json(created, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 400 });
  }
}

export async function PATCH(req: Request) {
  try {
    const body = await req.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    const [updated] = await db
      .update(products)
      .set(data)
      .where(eq(products.id, id))
      .returning();
    return NextResponse.json(updated);
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db.delete(products).where(eq(products.id, parseInt(id, 10)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 400 });
  }
}
