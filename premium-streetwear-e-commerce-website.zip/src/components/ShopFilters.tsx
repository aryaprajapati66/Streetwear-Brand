"use client";

import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { useState } from "react";
import { SlidersHorizontal, X, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";

type Facets = {
  categories: string[];
  collections: string[];
  colors: string[];
  sizes: string[];
};

export default function ShopFilters({ facets, current }: { facets: Facets; current: Record<string, string | undefined> }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [open, setOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);

  const update = (key: string, value?: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (!value) params.delete(key);
    else params.set(key, value);
    router.push(`${pathname}?${params.toString()}`);
    setOpen(false);
  };

  const clearAll = () => {
    const params = new URLSearchParams();
    if (current.q) params.set("q", current.q);
    if (current.gender) params.set("gender", current.gender);
    router.push(`${pathname}?${params.toString()}`);
  };

  const activeCount = [current.category, current.collection, current.color, current.size, current.new, current.sale, current.minPrice, current.maxPrice]
    .filter(Boolean).length;

  const SORTS = [
    { label: "Newest", value: "newest" },
    { label: "Price: Low to High", value: "price-asc" },
    { label: "Price: High to Low", value: "price-desc" },
    { label: "Popular", value: "popular" },
  ];

  const currentSortLabel = SORTS.find((s) => s.value === (current.sort || "newest"))?.label || "Newest";

  return (
    <div className="px-4 md:px-8 max-w-[1600px] mx-auto sticky top-[96px] md:top-[108px] z-20 bg-noir/80 backdrop-blur-md border-y border-white/5 py-3">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setOpen(!open)}
            className={cn(
              "inline-flex items-center gap-2 border px-4 py-2.5 text-xs tracking-[0.2em] font-bold transition-colors shrink-0",
              open || activeCount > 0
                ? "bg-bone text-noir border-bone"
                : "border-white/15 hover:border-bone text-bone"
            )}
          >
            <SlidersHorizontal size={14} />
            FILTERS {activeCount > 0 && `(${activeCount})`}
          </button>

          {/* Quick filter chips */}
          {current.category && (
            <Chip label={`Category: ${current.category}`} onRemove={() => update("category", undefined)} />
          )}
          {current.collection && (
            <Chip label={`Collection: ${current.collection}`} onRemove={() => update("collection", undefined)} />
          )}
          {current.color && (
            <Chip label={`Color: ${current.color}`} onRemove={() => update("color", undefined)} />
          )}
          {current.size && (
            <Chip label={`Size: ${current.size}`} onRemove={() => update("size", undefined)} />
          )}
          {current.new === "1" && (
            <Chip label="New arrivals" onRemove={() => update("new", undefined)} />
          )}
          {activeCount > 0 && (
            <button onClick={clearAll} className="text-xs tracking-[0.2em] text-noir-400 hover:text-bone shrink-0 px-2">
              CLEAR
            </button>
          )}
        </div>

        <div className="relative shrink-0">
          <button
            onClick={() => setSortOpen(!sortOpen)}
            className="inline-flex items-center gap-2 border border-white/15 px-4 py-2.5 text-xs tracking-[0.2em] font-bold hover:border-bone"
          >
            SORT: {currentSortLabel.toUpperCase()}
            {sortOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
          {sortOpen && (
            <div className="absolute right-0 top-full mt-2 bg-noir-900 border border-white/10 min-w-[220px] z-30">
              {SORTS.map((s) => (
                <button
                  key={s.value}
                  onClick={() => {
                    update("sort", s.value === "newest" ? undefined : s.value);
                    setSortOpen(false);
                  }}
                  className={cn(
                    "w-full text-left px-4 py-3 text-xs tracking-[0.15em] hover:bg-white/5",
                    currentSortLabel === s.label ? "text-bone" : "text-noir-400"
                  )}
                >
                  {s.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {open && (
        <div className="mt-3 border-t border-white/10 pt-5 grid grid-cols-2 md:grid-cols-4 gap-6 animate-fade-in">
          <FilterGroup
            title="CATEGORY"
            options={facets.categories}
            selected={current.category}
            onSelect={(v) => update("category", v === current.category ? undefined : v)}
          />
          <FilterGroup
            title="COLLECTION"
            options={facets.collections}
            selected={current.collection}
            onSelect={(v) => update("collection", v === current.collection ? undefined : v)}
          />
          <FilterGroup
            title="COLOR"
            options={facets.colors}
            selected={current.color}
            onSelect={(v) => update("color", v === current.color ? undefined : v)}
          />
          <FilterGroup
            title="SIZE"
            options={facets.sizes}
            selected={current.size}
            onSelect={(v) => update("size", v === current.size ? undefined : v)}
          />
        </div>
      )}
    </div>
  );
}

function Chip({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <span className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-3 py-2 text-xs tracking-wider shrink-0">
      {label}
      <button onClick={onRemove} className="hover:text-bone">
        <X size={12} />
      </button>
    </span>
  );
}

function FilterGroup({
  title,
  options,
  selected,
  onSelect,
}: {
  title: string;
  options: string[];
  selected?: string;
  onSelect: (v: string) => void;
}) {
  return (
    <div>
      <h4 className="text-[10px] tracking-[0.3em] text-noir-500 mb-3">{title}</h4>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onSelect(o)}
            className={cn(
              "border px-3 py-1.5 text-xs tracking-wide transition-colors",
              selected === o
                ? "bg-bone text-noir border-bone"
                : "border-white/15 text-noir-300 hover:border-bone hover:text-bone"
            )}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}
