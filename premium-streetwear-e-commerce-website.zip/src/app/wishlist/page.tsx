"use client";

import { useEffect, useState } from "react";
import ProductCard from "@/components/ProductCard";
import { useStore } from "@/lib/store";
import { Heart } from "lucide-react";
import Link from "next/link";

type Product = {
  id: number;
  slug: string;
  name: string;
  price: number;
  compareAtPrice?: number | null;
  images: string[];
  rating: number;
  reviewCount: number;
  sizes: string[];
  category: string;
};

export default function WishlistPage() {
  const { wishlist } = useStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (wishlist.length === 0) {
        setProducts([]);
        setLoading(false);
        return;
      }
      try {
        const all = await fetch("/api/products").then((r) => r.json());
        setProducts(all.filter((p: Product) => wishlist.includes(p.id)));
      } catch {
        setProducts([]);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [wishlist]);

  if (loading) {
    return (
      <div className="pt-32 md:pt-40 min-h-[60vh] text-center text-noir-500">Loading…</div>
    );
  }

  return (
    <div className="pt-28 md:pt-32">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 py-12">
        <div className="mb-10">
          <p className="text-xs tracking-[0.3em] text-noir-500 mb-2">SAVED FOR LATER</p>
          <h1 className="text-4xl md:text-6xl font-black tracking-[-0.03em]">WISHLIST</h1>
        </div>

        {products.length === 0 ? (
          <div className="py-24 text-center">
            <Heart size={48} className="mx-auto text-noir-500 mb-6" />
            <h2 className="text-2xl font-bold mb-3">Your wishlist is empty</h2>
            <p className="text-noir-400 mb-6">Save your favorite pieces here.</p>
            <Link
              href="/shop"
              className="inline-block bg-bone text-noir px-8 py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90"
            >
              BROWSE PRODUCTS
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
