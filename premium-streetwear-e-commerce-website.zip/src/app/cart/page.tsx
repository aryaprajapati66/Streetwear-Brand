"use client";

import Link from "next/link";
import Image from "next/image";
import { X, Minus, Plus, ShoppingBag, ArrowRight } from "lucide-react";
import { useStore } from "@/lib/store";
import { formatPrice } from "@/lib/utils";

export default function CartPage() {
  const { cart, updateQuantity, removeFromCart, subtotal, clearCart } = useStore();
  const sub = subtotal();
  const shipping = sub > 150 ? 0 : 12;
  const total = sub + shipping;

  if (cart.length === 0) {
    return (
      <div className="pt-32 md:pt-40 min-h-[70vh]">
        <div className="max-w-[1600px] mx-auto px-4 md:px-8 text-center">
          <ShoppingBag size={48} className="mx-auto text-noir-500 mb-6" />
          <h1 className="text-4xl md:text-6xl font-black tracking-[-0.03em] mb-4">YOUR CART IS EMPTY</h1>
          <p className="text-noir-400 mb-8">Add some pieces to get started.</p>
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 bg-bone text-noir px-8 py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 transition-colors"
          >
            CONTINUE SHOPPING <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28 md:pt-32">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 py-12">
        <h1 className="text-4xl md:text-6xl font-black tracking-[-0.03em] mb-10">YOUR CART</h1>

        <div className="grid lg:grid-cols-[1fr_400px] gap-12">
          {/* Items */}
          <div>
            <div className="space-y-6">
              {cart.map((item) => (
                <div key={`${item.productId}-${item.size}`} className="flex gap-4 md:gap-6 pb-6 border-b border-white/10">
                  <Link href={`/product/${item.slug}`} className="relative w-24 h-32 md:w-32 md:h-40 bg-noir-800 shrink-0">
                    <Image src={item.image} alt={item.name} fill className="object-cover" sizes="128px" />
                  </Link>
                  <div className="flex-1 flex flex-col">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <Link href={`/product/${item.slug}`} className="text-sm md:text-base font-bold hover:underline">
                          {item.name}
                        </Link>
                        <p className="text-xs text-noir-500 mt-1">Size: {item.size}</p>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.productId, item.size)}
                        className="p-1 hover:text-bone text-noir-500"
                        aria-label="Remove"
                      >
                        <X size={16} />
                      </button>
                    </div>
                    <div className="flex items-end justify-between mt-auto">
                      <div className="inline-flex items-center border border-white/15">
                        <button
                          onClick={() => updateQuantity(item.productId, item.size, Math.max(1, item.quantity - 1))}
                          className="w-8 h-8 flex items-center justify-center hover:bg-white/5"
                          aria-label="Decrease"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="w-8 text-center text-xs font-bold">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.size, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center hover:bg-white/5"
                          aria-label="Increase"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                      <div className="text-right">
                        <div className="text-sm md:text-base font-bold">{formatPrice(item.price * item.quantity)}</div>
                        {item.quantity > 1 && (
                          <div className="text-xs text-noir-500">{formatPrice(item.price)} each</div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={clearCart}
              className="mt-6 text-xs tracking-[0.2em] text-noir-500 hover:text-bone transition-colors"
            >
              CLEAR CART
            </button>
          </div>

          {/* Summary */}
          <div className="lg:sticky lg:top-28 lg:self-start bg-noir-900 border border-white/10 p-6 md:p-8">
            <h2 className="text-xl font-bold mb-6">ORDER SUMMARY</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-noir-400">Subtotal</span>
                <span>{formatPrice(sub)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-noir-400">Shipping</span>
                <span>{shipping === 0 ? "FREE" : formatPrice(shipping)}</span>
              </div>
              {sub < 150 && (
                <p className="text-xs text-noir-500">
                  Add {formatPrice(150 - sub)} more for free shipping
                </p>
              )}
              <div className="pt-3 border-t border-white/10 flex justify-between text-base font-bold">
                <span>Total</span>
                <span>{formatPrice(total)}</span>
              </div>
            </div>
            <Link
              href="/checkout"
              className="mt-6 w-full bg-bone text-noir py-4 text-xs tracking-[0.25em] font-bold hover:bg-bone/90 transition-colors flex items-center justify-center gap-2 btn-press"
            >
              CHECKOUT <ArrowRight size={14} />
            </Link>
            <Link
              href="/shop"
              className="mt-3 w-full border border-white/15 py-3 text-xs tracking-[0.25em] font-bold hover:border-bone transition-colors flex items-center justify-center"
            >
              CONTINUE SHOPPING
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
