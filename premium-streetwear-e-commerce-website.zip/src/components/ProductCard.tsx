"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, Plus } from "lucide-react";
import { useStore } from "@/lib/store";
import { formatPrice } from "@/lib/utils";
import { useState } from "react";

export type Product = {
  id: number;
  slug: string;
  name: string;
  price: number;
  compareAtPrice?: number | null;
  images: string[];
  rating: number;
  reviewCount: number;
  sizes: string[];
  category: string;
};

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const wishlisted = isWishlisted(product.id);
  const [imgIdx, setImgIdx] = useState(0);
  const mainImg = product.images[imgIdx] || product.images[0];
  const hoverImg = product.images[1] || mainImg;

  const quickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(
      {
        productId: product.id,
        name: product.name,
        slug: product.slug,
        image: mainImg,
        size: product.sizes[0] || "M",
        price: product.price,
      },
      1
    );
  };

  const toggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div className="group">
      <Link href={`/product/${product.slug}`} className="block">
        <div className="relative aspect-[4/5] bg-noir-800 overflow-hidden mb-4">
          <Image
            src={mainImg}
            alt={product.name}
            fill
            className="object-cover zoom-img opacity-100 group-hover:opacity-0 transition-opacity duration-500"
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
            priority={false}
          />
          {product.images.length > 1 && (
            <Image
              src={hoverImg}
              alt={product.name}
              fill
              className="object-cover zoom-img opacity-0 group-hover:opacity-100 transition-opacity duration-700"
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
            />
          )}

          {/* Sale badge */}
          {product.compareAtPrice && (
            <span className="absolute top-3 left-3 text-[10px] tracking-[0.2em] bg-bone text-noir px-2 py-1 font-bold z-10">
              SALE
            </span>
          )}

          {/* Wishlist */}
          <button
            onClick={toggle}
            className="absolute top-3 right-3 p-2 bg-noir/40 backdrop-blur-sm hover:bg-noir/80 transition-colors z-10"
            aria-label="Add to wishlist"
          >
            <Heart
              size={14}
              fill={wishlisted ? "#f5f5f0" : "none"}
              className={wishlisted ? "text-bone" : "text-bone"}
            />
          </button>

          {/* Quick add */}
          <button
            onClick={quickAdd}
            className="absolute bottom-0 left-0 right-0 bg-bone text-noir py-3 text-xs tracking-[0.25em] font-bold opacity-0 group-hover:opacity-100 translate-y-full group-hover:translate-y-0 transition-all duration-400 flex items-center justify-center gap-2 z-10 btn-press"
          >
            <Plus size={14} /> QUICK ADD
          </button>
        </div>
      </Link>

      <Link href={`/product/${product.slug}`} className="block">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <p className="text-[10px] tracking-[0.2em] text-noir-500 mb-1">
              {product.category.toUpperCase()}
            </p>
            <h3 className="text-sm font-medium text-bone truncate group-hover:underline underline-offset-4 decoration-noir-400">
              {product.name}
            </h3>
            <div className="flex items-center gap-1 mt-1 text-[11px] text-noir-400">
              <span>★ {product.rating.toFixed(1)}</span>
              <span className="text-noir-600">({product.reviewCount})</span>
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-sm font-medium">
              {product.compareAtPrice && (
                <span className="text-noir-500 line-through text-xs mr-2">
                  {formatPrice(product.compareAtPrice)}
                </span>
              )}
              <span>{formatPrice(product.price)}</span>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}
