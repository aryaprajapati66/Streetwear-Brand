import { notFound } from "next/navigation";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import ProductDetail from "@/components/ProductDetail";
import ProductRecommendations from "@/components/ProductRecommendations";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const [p] = await db.select().from(products).where(eq(products.slug, slug));
  if (!p) return { title: "Not found" };
  return {
    title: p.name,
    description: p.description?.slice(0, 160),
    openGraph: {
      title: p.name,
      description: p.description?.slice(0, 160),
      images: p.images[0] ? [{ url: p.images[0] }] : undefined,
    },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [product] = await db.select().from(products).where(eq(products.slug, slug));
  if (!product) notFound();

  return (
    <div className="pt-24 md:pt-28">
      <ProductDetail product={product} />
      <ProductRecommendations category={product.category} excludeId={product.id} />
    </div>
  );
}
